#ifndef MENU_H
#define MENU_H

#define true 1
#define false 0


int menu(int, NoLista**, Descritor*);

#endif
