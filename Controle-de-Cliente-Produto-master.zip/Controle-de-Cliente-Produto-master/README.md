#Controle-de-Cliente-Produto

Trabalho de estrutura de Dados para criar uma aplicação básica de controle de produtos e cliente, com a implementação de listas 
simplesmente encadeadas e listas com descritor.
 
#Execution

	cd into the folder that corresponds your system and execute the command make, everything will de done afterwards

 versão 1.1.0 
